from bottle import route, run, request, response

api_info = {'name': 'My api', 'version': '0.0.1'}

log_file_name = '/tmp/logs.txt'
log_file = open(log_file_name, 'a+')


@route('/api', method='GET')
def api_home():
    return api_info


@route('/api/log', method='GET')
def get_logs():
    log_file.seek(0, 0)
    text = log_file.read()

    response.content_type = 'text/plain'
    return text


@route('/api/log', method='POST')
def post_logs():
    text = request.forms.get('log')
    log_file.write(text + '\n')

    response.status = 201
    return

if __name__ == '__main__':
    run(host='0.0.0.0', port=8080)
