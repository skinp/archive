#!/usr/bin/env python
import sys
import random

facilities = ['kern', 'user', 'mail', 'lpr', 'auth', 'daemon', 'news', 'uucp', 'local0',
              'local1', 'local2', 'local3', 'local4', 'local5', 'local6', 'local7', 'mark']

priorities = ['emerg', 'alert', 'crit', 'err', 'warning', 'notice', 'info', 'debug', 'none']

number_of_messages = 100

for i in range(number_of_messages):
    facility = facilities[random.choice(range(len(facilities)))]
    priority = priorities[random.choice(range(len(priorities)))]
    print('%(facility)s.%(priority)s: Test %(number)d' % {'facility': facility, 'priority': priority, 'number': i})
