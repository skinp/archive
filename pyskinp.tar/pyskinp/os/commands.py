#!/usr/bin/env python
import os
import sys


def ls(folder=None):
    if folder is None:
        print("  ".join(os.listdir(os.getcwd())))
    else:
        print("  ".join(os.listdir(folder)))


def ll(folder=None):
    if folder is None:
        print("\n".join(os.listdir(os.getcwd())))
    else:
        print("\n".join(os.listdir(folder)))


def cd(folder=None):
    if folder is None:
        print("Usage: {0} folder".format(sys._getframe().f_code.co_name))
    else:
        os.chdir(folder)


def pwd():
    print(os.getcwd())


def cat(file):
    f = open(file, "r")
    print(f.read())

if __name__ == '__main__':
    import code
    code.interact(local=locals())
