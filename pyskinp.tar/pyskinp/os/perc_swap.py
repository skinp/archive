#!/usr/bin/env python
import subprocess

if __name__ == '__main__':
    process = subprocess.Popen('free', stdout=subprocess.PIPE)
    out, err = process.communicate()
    part, total = out.split()[19], out.split()[18]
    perc = float(part)/float(total) * 100
    print '%.2f' % (perc)
