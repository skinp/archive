#!/usr/bin/env python
# Run a system command
# author: Patrick Pelletier

import subprocess

class CommandError(Exception):
    pass

def run_command(args, data=None):
    ''' runs a command and return results. supports sending stdin data'''

    if isinstance(args, list):
        shell = False
    elif isinstance(args, basestring):
        shell = True
    else:
        raise CommandError("Unsupported command type")

    std_in = None
    if data:
        std_in = subprocess.PIPE

    try:
        cmd = subprocess.Popen(args, shell=shell, stdin=std_in, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if data:
            cmd.stdin.write(data)
            cmd.stdin.write('\\n')
        out, err = cmd.communicate()
        rc = cmd.returncode
    except (OSError, IOError), e:
        raise CommandError(e)

    return (out, err, rc)

if __name__ == "__main__":
    import sys

    if len(sys.argv) <= 1:
        print "Usage: %s <cmd>" % sys.argv[0]
        sys.exit(1)

    print run_command(" ".join(sys.argv[1:])),
