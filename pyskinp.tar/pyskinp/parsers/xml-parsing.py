# coding: utf-8
from xml.dom import minidom
dom = minidom.parse("FILENAME")
hs = dom.getElementsByTagName("TAGNAME")
res = []
for i in hs:
    d = {}
    d['name'] = i.getAttribute("ATTRIBUTENAME")
    res.append(d)

print res
