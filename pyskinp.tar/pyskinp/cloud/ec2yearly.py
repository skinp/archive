#!/usr/bin/env python
#urls:  http://aws.amazon.com/en/ec2/pricing/pricing-on-demand-instances.json/
#       http://aws.amazon.com/en/ec2/pricing/pricing-reserved-instances.json/

import json
import sys

jsonfile = open(sys.argv[1], 'r')

ec2 = json.load(jsonfile)


print "Total yearly cost of ec2 instances:"

for i in ec2["config"]["regions"]:
    if i["region"] == "us-east":
        for j in i["instanceTypes"]:
            print j["type"]
            for h in j["sizes"]:
                yrdepot = 0
                hrprice = 0
                for k in h["valueColumns"]:
                    if k["name"] == "yrTerm1":
                        yrdepot = k["prices"]["USD"]

                for k in h["valueColumns"]:
                    if k["name"] == "linux":
                        hrprice = k["prices"]["USD"]

                print h["size"], float(hrprice)*24*365+float(yrdepot)
            print
