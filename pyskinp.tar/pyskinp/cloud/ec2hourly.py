#!/usr/bin/env python
#urls:  http://aws.amazon.com/en/ec2/pricing/pricing-on-demand-instances.json/
#       http://aws.amazon.com/en/ec2/pricing/pricing-reserved-instances.json/
import json
import sys

ec2_jsonfile = open(sys.argv[1], 'r')
ec2 = json.load(ec2_jsonfile)

for i in ec2["config"]["regions"]:
    if i["region"] == "us-east":
        for j in i["instanceTypes"]:
            print j["type"]
            for h in j["sizes"]:
                for k in h["valueColumns"]:
                    if k["name"] == "linux":
                        hrprice = k["prices"]["USD"]
                print h["size"], hrprice
            print
