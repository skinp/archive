import urllib2
import threading


class Requester(threading.Thread):
    """ Multiple http request thread"""

    def __init__(self, url, num_requests):
        self._url = url
        self._num_requests = num_requests
        super(Requester, self).__init__()

    def _request(self, req_id):
        params = "?req_id=%s&thread_id=%s" % (req_id, self.getName())
        req = urllib2.urlopen(self._url + "/" + params)
        #req = urllib2.urlopen(self._url)
        return req.code

    def run(self):
        for i in range(self._num_requests):
            code = self._request(i)
            if code != 200:
                print "Request #" + str(i) + " in worker " + self.getName() + " code " + str(code)

if __name__ == '__main__':
    import sys

    print "START"
    t = []
    for i in range(10):
        request = Requester(sys.argv[1], 1000)
        request.start()
        t.append(request)

    for r in t:
        r.join()
    print "STOP"
