#!/usr/bin/env python
import sys
import urllib2
import httplib
import json


def request_availability(proxy):
    if proxy:
        proxy_handler = urllib2.ProxyHandler({'http': 'http://127.0.0.1:3128'})
        opener = urllib2.build_opener(proxy_handler)
        urllib2.install_opener(opener)

    url = "http://doesbuyvmhavestock.com/automation.json"
    webrequest = urllib2.urlopen(url, timeout=5)
    availabilitydata = json.loads(webrequest.read())
    webrequest.close()

    return availabilitydata


if __name__ == '__main__':

    interesting_vms = (67, 46, 47, 86)
    proxy = False

    if len(sys.argv) == 2 and sys.argv[1] == "-p":
        proxy = True

    try:
        availabilitydata = request_availability(proxy)
    except httplib.BadStatusLine:
        sys.stderr.write("BadStatusLine... retrying now...")
        print
        availabilitydata = request_availability(proxy)

    for plan in availabilitydata:
#        if plan["pid"] in interesting_vms :
#            print "There is " + str(plan["qty"]) + " VM available for " + plan["name"]
        print "There is " + str(plan["qty"]) + " VM available for " + plan["name"]
