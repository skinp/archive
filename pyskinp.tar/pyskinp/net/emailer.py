#!/usr/bin/env python
# Email helper class and program
# author: Patrick Pelletier

import smtplib
import os.path
from email.MIMEMultipart import MIMEMultipart
from email.MIMEBase import MIMEBase
from email.MIMEText import MIMEText
from email import Encoders


class Emailer(object):
    ''' Utility class used to send email and attach files.'''

    def __init__(self, email_server, email_from, email_to, subject, body=None):
        ''' Construct the email basic stucture.'''

        self.email_server = email_server
        self.email_from = email_from
        self.email_to = email_to

        self.subject = subject
        self.body = body

        # Most basic email structure needed.
        self.msg = MIMEMultipart()
        self.msg['Subject'] = self.subject
        self.msg['From'] = self.email_from
        self.msg['To'] = ', '.join(self.email_to)

        self.msg.attach(MIMEText(self.body))

    def attach(self, filename):
        ''' Reads a file and attach it to email.'''

        part = MIMEBase('application', "octet-stream")
        part.set_payload(open(filename, "rb").read())
        Encoders.encode_base64(part)
        part.add_header('Content-Disposition', 'attachment; filename="%s"' % os.path.basename(filename))

        self.msg.attach(part)

    def send(self):
        ''' Sends the email.'''

        server = smtplib.SMTP(self.email_server)
        server.sendmail(self.email_from, self.email_to, self.msg.as_string())


if __name__ == '__main__':
    import sys
    import os
    from optparse import OptionParser

    # CLI arguments parsing
    usage = "usage: %prog [--server server.example.com] [-f from] [-s subject] [-a file [-a ...]] dst_address [...]"
    parser = OptionParser(usage=usage)
    parser.add_option("--server", dest="server", action="store",
                      help="mail server", metavar="server")
    parser.add_option("-f", dest="email_from", action="store",
                      help="send mail from", metavar="email_from")
    parser.add_option("-s", dest="subject", action="store",
                      help="subject of email", metavar="subject")
    parser.add_option("-a", dest="filenames", action="append",
                      help="attach file to email", metavar="file")
    (options, args) = parser.parse_args()

    email_to = args
    if not email_to:
        parser.error("you must provide at least 1 destination address...")

    # Default server and sender
    if not options.server:
        options.server = "localhost"
    if not options.email_from:
        from getpass import getuser
        from socket import gethostname
        username = getuser()
        hostname = gethostname()
        options.email_from = "%s@%s" % (username, hostname)

    # Body is from STDIN
    body = None
    if not sys.stdin.isatty():
        body = sys.stdin.read()

    e = Emailer(options.server, options.email_from, email_to, options.subject, body)

    # Add attachments
    if options.filenames:
        for a in options.filenames:
            e.attach(a)

    e.send()
