#!/usr/bin/env python
import urllib2
import sys

if __name__ == '__main__':

    if len(sys.argv) != 2:
        print("Usage: " + sys.argv[0] + " URL")
        sys.exit(1)
    proxy_handler = urllib2.ProxyHandler({'http': 'http://127.0.0.1:3128'})
    opener = urllib2.build_opener(proxy_handler)
    urllib2.install_opener(opener)

    f = urllib2.urlopen(sys.argv[1])

    fh = open('download.bin', 'wb')
    fh.write(f.read())
    fh.close
