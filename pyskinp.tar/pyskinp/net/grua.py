#!/usr/bin/env python

import urllib
import urllib2
from getpass import getpass
from xml.dom import minidom


class Grua:

    def __init__(self, username, password):
        self._username = username
        self._password = password
        self._auth = self.__get_auth()
        self._token = self.__get_token()

    def __get_auth(self):
        auth_url = 'https://www.google.com/accounts/ClientLogin'
        auth_data = urllib.urlencode({
            'Email': self._username,
            'Passwd': self._password,
            'service': 'reader'
        })
        auth_req = urllib2.Request(auth_url, data=auth_data)
        auth_resp = urllib2.urlopen(auth_req).read()
        auth_resp_dict = dict(x.split('=') for x in auth_resp.split('\n') if x)
        auth_key = auth_resp_dict["Auth"]
        return auth_key

    def __get_token(self):
        token_url = 'https://www.google.com/reader/api/0/token'
        token_req = urllib2.Request(token_url)
        token_req.add_header('Authorization', 'GoogleLogin auth=%s' % self._auth)
        return urllib2.urlopen(token_req).readlines()[0]

    def __get_starred(self):
        starred_url = 'http://www.google.com/reader/atom/user/-/state/com.google/starred'
        starred_req = urllib2.Request(starred_url)
        starred_req.add_header('Authorization', 'GoogleLogin auth=%s' % self._auth)
        return urllib2.urlopen(starred_req).read()

    def __parse_feed(self, feed_str):
        xml_tree = minidom.parseString(feed_str)
        starred_items = []
        for item in xml_tree.getElementsByTagName("entry"):
            starred_items.append(item.getElementsByTagName("id")[0].firstChild.nodeValue)
        return starred_items

    def unstar_all(self):
        unstar_url = 'http://www.google.com/reader/api/0/edit-tag'
        starred_list = self.__parse_feed(self.__get_starred())
        while(starred_list):
            for starred_item in starred_list:
                post_data = {'i': starred_item,
                             'ac': 'edit',
                             'r': 'user/-/state/com.google/starred',
                             'T': self._token}
                unstar_req = urllib2.Request(unstar_url, data=urllib.urlencode(post_data))
                unstar_req.add_header('Authorization', 'GoogleLogin auth=%s' % self._auth)
                print urllib2.urlopen(unstar_req).read()
            starred_list = self.__parse_feed(self.__get_starred())

if __name__ == '__main__':

    username = raw_input("Username: ")
    password = getpass("Password: ")
    g = Grua(username, password)
    g.unstar_all()
