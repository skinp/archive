#!/usr/bin/env python
# genpass.py
# Random password generation
# author: Patrick Pelletier

import md5
import random


def genpass(len=20):
    ''' generates a random password based on the md5 of a random float '''

    hash = md5.new()
    hash.update(str(random.random()))
    temppass = hash.hexdigest()[:len]
    password = ''
    for char in temppass:
        if char.isalpha() and random.choice([True, False]):
            char = char.upper()
        password += char
    return password

if __name__ == "__main__":
    import sys

    # prints usage and exits
    def usage():
        print "usage: %s [-h|<number_of_pass>]" % sys.argv[0]
        sys.exit(1)

    times = 1

    # checks and process CLI arguments
    if len(sys.argv) > 2:
        usage()
    elif len(sys.argv) == 2:
        if sys.argv[1] == '-h':
            usage()
        else:
            try:
                times = int(sys.argv[1])
            except ValueError:
                usage()

    for i in xrange(times):
        print genpass()
