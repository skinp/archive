#!/usr/bin/env python

import BeautifulSoup
import sys
import re

email = sys.stdin.read()
soup = BeautifulSoup.BeautifulSoup(email)

[soup.contents.remove(child) for child in soup.contents if isinstance(child, BeautifulSoup.Declaration)]
[s.extract() for s in soup('style')]

wanted_text = []

for line in soup.findAll(text=True):
    line = re.sub(r'&nbsp;', ' ', line)
    line = re.sub(r'=\n', '', line)
    line = re.sub(r'^\n$', '', line)
    line = re.sub(r'^ $', '', line)
    if line:
        wanted_text.append(line)

for i in wanted_text:
    print i,
