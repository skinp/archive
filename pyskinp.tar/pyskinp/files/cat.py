#!/usr/bin/env python

import sys

if __name__ == '__main__':
    filename = sys.argv[1]
    lines = []
    try:
        f = open(filename, 'r')
        try:
            for i in f:
                lines.append(i)
        finally:
            f.close()
    except IOError, (errno, errmsg):
        print "Error: %s : %s" % (errmsg, filename)
        sys.exit(1)

    print ''.join(lines),
