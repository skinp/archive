#!/usr/bin/env python
import time


def tailf(filename):
    f = open(filename, 'r')
    f.seek(0, 2)
    while True:
        line = f.readline()
        if not line:
            time.sleep(0.1)
            continue
        yield line


def filter(string, pattern):
    for i in string:
        if pattern in i:
            yield i

if __name__ == '__main__':
    import sys
    filename = sys.argv[1]
    pattern = sys.argv[2]

    follow = tailf(filename)
    filtered = filter(follow, pattern)

    for i in filtered:
        print i,
