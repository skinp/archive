#!/usr/bin/env python
# Tail a file
# author: Patrick Pelletier
import time


def tailf(filename):
    f = open(filename, 'r')
    f.seek(0, 2)
    while True:
        line = f.readline()
        if not line:
            time.sleep(0.1)
            continue
        yield line

if __name__ == '__main__':
    import sys

    if len(sys.argv) <= 1:
        print "Usage: %s <filename>" % sys.argv[0]
        sys.exit(1)

    filename = sys.argv[1]
    for i in tailf(filename):
        print i,
