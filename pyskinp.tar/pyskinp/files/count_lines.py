#!/usr/bin/env python
import sys
import glob
import gzip
import bz2
import timeit
import itertools


def gen_open(filenames):
    for filename in filenames:
        if filename.endswith('gz'):
            yield (gzip.open(filename), filename)
        elif filename.endswith('bz2'):
            yield (bz2.BZ2File(filename), filename)
        else:
            yield (open(filename), filename)


def count_lines(pattern):
    filenames = glob.glob(pattern)
    filenames.sort()

    files = gen_open(filenames)
    #files = itertools.islice(files, 15, 20)

    for file, filename in files:
        nl = 0
        for line in file:
            nl += 1
        yield filename, nl

if __name__ == '__main__':
    pattern = sys.argv[1]
    command = "for filename, nl in count_lines(pattern): print filename, nl;"
    imports = "from __main__ import count_lines, pattern"
    t = timeit.Timer(command, imports)
    print t.timeit(1)
