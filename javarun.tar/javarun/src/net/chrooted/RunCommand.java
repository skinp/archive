package net.chrooted;

import java.util.Arrays;

class RunCommand {
    public static void main(String[] args) {
        if (args.length == 0) {
            System.out.println("Must have an argument");
            System.exit(1);
        }
        StringBuilder cmdstr = new StringBuilder();
        for (String s : args) {
            cmdstr.append(s).append(" ");
        }

        Command cmd = new Command(cmdstr.toString());
        cmd.run();
        System.out.print(cmd.getOutput());
    }
}
