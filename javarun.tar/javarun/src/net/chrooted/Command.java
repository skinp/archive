package net.chrooted;

import java.io.*;

class Command {
    private String cmdstr;
    private String result;

    public Command(String cmdstr) {
        this.cmdstr = cmdstr;
        this.result = null;
    }

    public String getOutput() {
        return this.result;
    }

    public void run() {
        StringBuilder output = new StringBuilder();

        try {
            Process proc = Runtime.getRuntime().exec(this.cmdstr);
            BufferedReader in = new BufferedReader(new InputStreamReader(proc.getInputStream()));

            String line = "";

            while ((line = in.readLine()) != null) {
                output.append(line).append("\n");
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        this.result = output.toString();

    }
}
