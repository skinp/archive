import socket

HOST = 'localhost'
PORT = 7777

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# No wait on connections... for load testing
#s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
s.connect((HOST, PORT))
s.send('Message')
print s.recv(1024)
s.close()
