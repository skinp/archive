import os
import operator
import re

apache_pattern = [
    r'(?P<host>\S+)',                   # host %h
    r'\S+',                             # indent %l (unused)
    r'(?P<user>\S+)',                   # user %u
    r'\[(?P<time>.+)\]',                # time %t
    r'"(?P<request>.+)"',               # request "%r"
    r'(?P<status>[0-9]+)',              # status %>s
    r'(?P<size>\S+)',                   # size %b (careful, can be '-')
    r'"(?P<referer>.*)"',               # referer "%{Referer}i"
    r'"(?P<agent>.*)"',                 # user agent "%{User-agent}i"
]
pattern = re.compile(r'\s+'.join(apache_pattern)+r'\s*\Z')

class Counter:
    def __init__(self):
        self.data = {}

    def insert(self, data):
        if data in self.data:
            self.data[data] += 1
        else:
            self.data[data] = 1

def get_log_files(pattern, dir):
    for file in os.listdir(dir):
        if file.startswith(pattern):
            yield file

def get_open_files(files):
    for file in files:
        yield open(file)

def get_file_lines(files):
    for file in files:
        for line in file:
            yield line

def convert_to_json(lines):
    for line in lines:
        m = pattern.match(line)
        yield m.groupdict()

def get_hosts(json_data):
    for json_line in json_data:
        yield json_line['host']

if __name__ == '__main__':
    filenames = get_log_files("ssl", ".")
    files = get_open_files(filenames)
    lines = get_file_lines(files)
    json_data = convert_to_json(lines)
    hosts = get_hosts(json_data)
    c = Counter()
    for host in hosts:
        c.insert(host)
    print sorted(c.data.iteritems(), key=operator.itemgetter(1))[::-1]
