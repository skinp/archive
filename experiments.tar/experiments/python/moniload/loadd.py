import socket


def server_loop():
    HOST = ('localhost', 7777)
    s = socket.socket()
    s.bind(HOST)
    s.listen(1)

    while 1:
        conn, addr = s.accept()
        data = conn.recv(1024)
        while data:
            print addr, data
            data = conn.recv(1024)

if __name__ == '__main__':
    exit(server_loop())
