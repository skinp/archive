import time
import socket


class Load:

    def __init__(self, load5, load10, load15):
        self.load5 = load5
        self.load10 = load10
        self.load15 = load15


def read_load_info():
    FILE = "/proc/loadavg"
    with open(FILE, "r") as f:
        data = f.read()
    return tuple(data.split()[:3])


def send_to_server(load):
    HOST = ('localhost', 7777)
    s = socket.socket()
    s.connect(HOST)
    s.send(str(load.__dict__))
    s.close()


def main():
    interval = 5

    while True:
        l5, l10, l15 = read_load_info()
        l = Load(l5, l10, l15)
        send_to_server(l)
        time.sleep(interval)


if __name__ == '__main__':
    exit(main())
