SYSLOG_DATE    = r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2})'
SYSLOG_LINE    = r'^%s (.*?) (.*?): (.*)$' % SYSLOG_DATE
SYSLOG_PROCESS = r'^(.*?)(?:\[(\d*)\])?$'
SNOOPY_MSG     = r'^\[uid:(\d*) sid:(\d*) tty:(.*?) cwd:(.*?) filename:(.*?)\]: (.*)$'
