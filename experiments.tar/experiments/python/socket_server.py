import socket

s = socket.socket()
s.bind(('127.0.0.1', 7777))
s.listen(2)

while 1:
    c, a = s.accept()
    print "connected", a

    data = c.recv(1024)
    while data:
        c.send(data)
        data = c.recv(1024)
