from bottle import run, route, request, response, hook

import json

@hook('after_request')
def enable_cors():
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Methods'] = 'PUT, GET, POST, DELETE, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Origin, Accept, Content-Type, X-Requested-With, X-CSRF-Token'

@route('/', method="GET")
def get_home():
    return { "version": "0.0.1" }

@route('/', method="POST")
def post_home():
    if not request.json:
        response.status = 400
        return { "error": "No json data received" }
    return request.json

@route('/', method="OPTIONS")
def options_home():
    return {}


if __name__ == '__main__':
    run(host='localhost', port=8080, debug=True)
