import os
import re
from matplotlib import pyplot as plt

processes = []
for dir, dirs, file in os.walk('/proc'):
    m = re.match(r"^/proc/(\d*)$", dir)
    if m:
        processes.append(int(m.groups()[0]))

plt.hist(processes)
plt.savefig("processes.png")
plt.close()
