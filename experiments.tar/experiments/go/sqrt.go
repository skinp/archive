//Estimate square root using Newton's method.
//Exercice from http://tour.golang.org/#23
package main

import (
	"fmt"
	"math"
)

func Sqrt(x float64) float64 {
	// Find a good starting point
	z := 0.0
	for {
		z++
		if z*z >= x {
			break
		}
	}

	previous_z := 0.0
	for math.Abs(previous_z-z) > 0.01 {
		previous_z = z
		z = z - (z*z-x)/(2.0*z)
	}
	return z
}

func main() {
	for i := 1.0; ; i++ {
		var mine = Sqrt(i)
		var gos = math.Sqrt(i)
		fmt.Println(i, ": ", Sqrt(mine), " vs ", math.Sqrt(gos), " Diff: ", mine-gos)
	}
}
