// Wrapper to run command in go
package main

import (
	"bytes"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strings"
)

func main() {
	if len(os.Args) != 2 {
		fmt.Fprintf(os.Stderr, "usage: %s <command>\n", os.Args[0])
		os.Exit(1)
	}

	cliargs := strings.Split(os.Args[1], " ")
	var bin = cliargs[0]
	var args = cliargs[1:]

	cmd := exec.Command(bin, args...)
	var out bytes.Buffer
	cmd.Stdout = &out

	err := cmd.Run()
	if err != nil {
		log.Fatal(err)
	}

	fmt.Print(out.String())
}
