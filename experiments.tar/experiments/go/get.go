// Download a file over http in go
package main

import (
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
)

type Website struct {
	name string
	url  string
}

func (w *Website) download() ([]byte, error) {
	resp, err := http.Get(w.url)
	if err != nil {
		return nil, err
	}

	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	return body, nil
}

func main() {
	if len(os.Args) != 3 {
		fmt.Fprintf(os.Stderr, "usage: %s <name> <url>\n", os.Args[0])
		os.Exit(1)
	}

	w := &Website{name: os.Args[1], url: os.Args[2]}
	page, err := w.download()
	if err != nil {
		log.Fatal("Error downloading \"", w.name, "\" from ", w.url, ". Error: ", err)
	}

	fmt.Print(string(page))
}
