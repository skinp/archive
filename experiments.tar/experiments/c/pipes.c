/* Takes input from stdin and pipes it to command in arguments
 *
 *  Made to replace "sh -c" call when using piped logs in apache
 *  since we don't want a shell in the chroot
 *
 * author: Patrick Pelletier
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void error(char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

int main(int argc, char *argv[]) {

    if ( argc != 3 || strncmp(argv[1], "-c", strlen(argv[1]))) {
        printf("usage: %s -c \"command [args]\"\n", argv[0]);
        exit(EXIT_SUCCESS);
    }

    char *binary = strtok(argv[2], " ");
    if (strncmp(binary, argv[0], strlen(binary)) == 0) {
        printf("%s cannot call itself\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    int numargs = 2;
    char **arguments = (char **) malloc(2*sizeof(char **));
    if (arguments == NULL) {
        error("unable to alloc memory for arguments");
    }

    arguments[0] = binary;

    char *argument;
    while ((argument = strtok(NULL, " ")) != NULL) {
        arguments[numargs-1] = argument;
        numargs++;
        arguments = (char **) realloc(arguments, numargs*sizeof(char **));
        if (arguments == NULL) {
            error("unable to realloc memory for more arguments");
        }
    }
    arguments[numargs-1] = NULL;

    int fd[2];
    if (pipe(fd) == -1) {
        error("unable to open pipe");
    }

    pid_t childpid;
    if ((childpid = fork()) == -1) {
        error("unable to fork");
    }

    if (childpid == 0) {
        if (dup2(fd[0], 0) < 0) {
            error("unable to dup in child");
        }
        close(fd[1]);

        if (execv(binary, arguments) < 0) {
            error("unable to exec in child");
        }
    } else {
        if (dup2(fd[1], 1) < 0) {
            error("unable to dup in parent");
        }
        close(fd[0]);

        char *line = NULL;
        size_t len = 0;
        ssize_t read;

        while ((read = getline(&line, &len, stdin)) != -1) {
            write(fd[1], line, read);
        }

        free(line);
    }

    free(arguments);
    exit(EXIT_SUCCESS);
}

