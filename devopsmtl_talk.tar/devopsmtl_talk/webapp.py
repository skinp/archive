import random
from bottle import route, run, request, response
from utils import write_graphite

GRAPHITE_HOST='localhost'
GRAPHITE_PORT=2003

@route('/', method='GET')
def index():
    value = random.randrange(0, 10)
    write_graphite("devopsmtl.webapp.values", value)
    write_graphite("devopsmtl.webapp.count", 1)
    return str(value)

if __name__ == '__main__':
    run(host='0.0.0.0', port=8080)
