You will need:
- ACCESS_KEY_ID & SECRET_ACCESS_KEY environment variables
- Your EC2 ssh key file named .ec2_key.pem (named graphite in EC2)
- Open ports in security group graphite: 22, 80, 8080, 2003, 8125 (UDP)

To view presentation:
- cd presentation; python -m SimpleHTTPServer
- browser: localhost:8000
