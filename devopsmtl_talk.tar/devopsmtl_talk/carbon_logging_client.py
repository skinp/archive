import logging
import random
import sys
from carbon_handler import CarbonHandler

if __name__ == '__main__':

    logger = logging.getLogger("devopsmtl.logger.random")
    logger.setLevel(logging.DEBUG)

    handler = CarbonHandler(sys.argv[1], 2003)
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.debug(random.randrange(0, 100))
