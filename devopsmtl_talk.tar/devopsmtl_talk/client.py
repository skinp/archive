import statsd
import sys
c = statsd.StatsClient(sys.argv[1], 8125)
c.incr('devopsmtl.statsd.count')
