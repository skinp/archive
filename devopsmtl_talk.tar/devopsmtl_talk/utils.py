import socket
import time

GRAPHITE_HOST = 'localhost'
GRAPHITE_PORT = 2003

def write_graphite(metric, value):
    s = socket.socket()
    s.connect((GRAPHITE_HOST, GRAPHITE_PORT))
    s.sendall("%s %d %d\n" % (metric, value, int(time.time())))
    s.close()
