//
//
//

function graph(options) {
    var that = { };

    var data = [];

    var canvas_name = options.canvas || "canvas";
    var showGrid = options.showgrid || "yes";
    var showValue = options.showvalue || "yes";

    var canvas = document.getElementById(canvas_name);
    var context = canvas.getContext("2d");

    // Update the graph with a new value
    that.update = function update(value) {
        if (data.length >= Math.floor(canvas.width/10)+1) {
            data.shift();
        }
        data.push(value);
        clearGraph();

        if (showGrid == "yes") {
            drawGrid();
        }
        drawGraph();
        if (showValue == "yes") {
            drawValue();
        }
    }

    /*
    that.save = function save() {
    }
    */

	// Clear the canvas
    function clearGraph() {
        context.clearRect (0 , 0 , canvas.width , canvas.height);
    }

    // Draw the graph of the values
    function drawGraph() {
        context.beginPath();
        context.moveTo(0, canvas.height);
        var lastx;
        for (var i=0; i<data.length; i++) {
            context.lineTo(i*10, canvas.height - data[i]*10);
            lastx = i*10;
        }
        context.lineTo(lastx, canvas.height);
        context.closePath();

        context.strokeStyle = 'rgba(255, 0, 0, 1)';
        context.stroke();
        context.fillStyle = 'rgba(255, 0 ,0, 0.5)';
        context.fill();
    }

    // Draw a grid on the canvas
    function drawGrid() {
        context.beginPath();
        for (var x = 0; x < canvas.width; x += 10) {
            context.moveTo(x, 0);
            context.lineTo(x, canvas.height);
        }
        for (var y = 0; y < canvas.height; y += 10) {
            context.moveTo(0, y);
            context.lineTo(canvas.width, y);
        }
        context.closePath();

        context.strokeStyle = 'rgba(238, 238, 238, 0.8)';
        context.stroke();
    }

    // Draw the current update's value in top right corner
    function drawValue() {
        context.textAlign = 'center';
        context.fillStyle = 'rgba(0, 0, 0, 1)';
        context.fillText(data[data.length - 1], canvas.width - 10, 10);
    }

    return that;
}
