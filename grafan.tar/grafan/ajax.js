//
//
//

function ajax(options) {
    var that = {};

    var url = options.url;
    var handler = options.handler;

    //
    that.request = function request() {
        try {
            var xmlhttp = window.XMLHttpRequest?new XMLHttpRequest(): new ActiveXObject("Microsoft.XMLHTTP");
        } catch (e) {
            // browser doesn't support ajax. handle however you want
        }

        xmlhttp.onreadystatechange = function () {
            if ((xmlhttp.readyState == 4) && (xmlhttp.status == 200)) {
                handler(xmlhttp.responseText); 
            }
        }
        xmlhttp.open("GET", url);
        xmlhttp.send(null);
    }

    return that;
}