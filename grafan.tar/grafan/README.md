grafan
======

Simple real-time JS graph using Canvas