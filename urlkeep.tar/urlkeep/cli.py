from bookmark import Bookmark
import time
import file_adapter
import os.path


if __name__ == '__main__':
    b1 = Bookmark('http://google.com')
    b2 = Bookmark('http://chrooted.net', title='My web page', tags=['sysadmin', 'security', 'personal'], date=time.gmtime()[:3])

    db_file = '/tmp/.bkmk_db'

    config = { 'file': db_file }
    db_access = file_adapter.BookmarkFileAdapter(config)

    db_access.create_bookmark(b1)
    db_access.create_bookmark(b2)
