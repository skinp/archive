import time
from hashlib import md5

class Bookmark(object):

    def __init__(self, url, title='', tags=list(), id=None, date=time.localtime()[:3]):
        self.url = url
        self.title = title
        self.date = date
        self.tags = tags

        if id is None:
            self.id = gen_bookmark_id(self.url)

def gen_bookmark_id(url):
   m = md5()
   m.update(url)
   return m.hexdigest()
