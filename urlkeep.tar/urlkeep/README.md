Model
-----

Bookmark:
    - id (string - hash of url)
    - url (string)
    - title (string)
    - date added (date)
    - tags (list)

Urlkeep:
    - bookmarks (dict of bookmark)

Actions
-------

- Create
- Read
- Update
- Delete

Web API
-------

- List all bookmarks (support for search query - search by  tags!)
    GET     /bookmarks

- Print one bookmarks
    GET     /bookmark/:id

- Add a bookmark
    POST    /bookmark

- Update a bookmark
    PUT     /bookmark/:id

- Delete a bookmark
    DELETE  /bookmark/:id

Ideas
-----

- domain of url (as property?)
- sorting (by date, site...)
