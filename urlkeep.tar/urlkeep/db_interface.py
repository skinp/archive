class BookmarkDBInterface(object):

    def __init__(self, config):
        raise NotImplementedError

    def read_bookmarks(self, query=None):
        raise NotImplementedError

    def read_bookmark(self, id):
        raise NotImplementedError

    def create_bookmark(self, bookmark):
        raise NotImplementedError

    def update_bookmark(self, bookmark):
        raise NotImplementedError

    def delete_bookmark(self, id):
        raise NotImplementedError
