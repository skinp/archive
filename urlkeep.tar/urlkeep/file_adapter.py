import json
import os.path

import bookmark
import db_interface

class BookmarkFileAdapter(db_interface.BookmarkDBInterface):

    def __init__(self, config):
        self._db = Database(config['file'])

    def create_bookmark(self, new_entry):
        new_entry = vars(new_entry)

        data = self._db.load()
        if data is None:
            data = list()

        data.append(new_entry)
        self._db.save(data)

    def read_bookmarks(self, query=None):
        raise NotImplementedError

    def read_bookmark(self, id):
        db = self.__read_json()
        for entry in db:
            if entry.id == id:
                return bookmark.Bookmark(entry)
        return None


class Database(dict):

    def __init__(self, path):
        dict.__init__(self)
        self.file = path

        if not os.path.exists(self.file):
            open(self.file, 'a').close()

    def load(self):
        try:
            with open(self.file, 'r') as f:
                data = json.load(f)
            return data
        except ValueError as e:
            return None

    def save(self, data):
        with open(self.file, 'w') as f:
            json.dump(data, f)
