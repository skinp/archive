function ajax(url, callback) {
    var x = new XMLHttpRequest();
    x.onreadystatechange = function(){
        if (x.readyState == 4) {
            callback(x.responseText);
        }
    };
    x.open("GET", url);
    x.send();
}
