setInterval(updateRndValue, 1000);

function updateRndValue() {
    ajax("/api/random", showRndValue);
}

function showRndValue(value){
    document.getElementById("rnd").innerHTML = value;
    console.log("value: " + value);
}
