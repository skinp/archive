exports.getInfo = function(req, res){
    var info = {};
    info.name = 'Patrick Pelletier';
    info.email = 'pp.pelletier@gmail.com';
    res.send(info);
};
