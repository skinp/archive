exports.getRnd = function(req, res){
    res.send(Math.random().toString());
};
