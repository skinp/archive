var express = require('express');
var random = require('./routes/random.js');
var contact = require('./routes/contact.js');
var app = express();

app.get('/api/random', random.getRnd);
app.get('/api/contact', contact.getInfo);

app.listen(8888);
console.log("Api listen on 8888");
