from bottle import route, run, request, response
from workers import Pool
from jobs import Job

pool = Pool(10)
jobs = {}

@route('/api', method='GET')
def api_home():
    return { "version": "0.0.1" }

@route('/api/jobs', method='GET')
def get_jobs():
    return { "jobs_id": jobs.keys() }

@route('/api/jobs/<id>', method='GET')
def get_job(id):
    if id in jobs.keys():
        job = jobs[id]
        if job.status == 'done':
            del(jobs[id])

        return job.__dict__
    else:
        response.status = 400
        return { "error": "Job id %s not found" % id }


@route('/api/jobs', method='POST')
def post_jobs():
    if not request.json:
        response.status = 400
        return { "error": "No json data received" }
    if not request.json.get("command"):
        response.status = 400
        return { "error": "Command argument needed" }

    job = Job(request.json.get("command"))
    jobs[job.id] = job
    pool.submit(job)
    return { "id": job.id }

if __name__ == '__main__':
    run(host='0.0.0.0', port=8080, debug=True)
