from random import random
from hashlib import md5
from datetime import datetime

from run import run_command

def generate_id():
    m = md5()
    m.update(str(random()))
    return m.hexdigest()

class Job(object):

    def __init__(self, command):
        self.id = generate_id()
        self.command = command
        self.status = "queued"

    def execute(self):
        self.status = "running"
        self.start_time = datetime.now().isoformat()

        (self.out, self.err, self.rc) = run_command(self.command)

        self.end_time = datetime.now().isoformat()
        self.status = "done"
