import threading
import Queue

class Worker(threading.Thread):

    def __init__(self, queue):
        super(Worker, self).__init__()
        self.queue = queue

    def run(self):
        while True:
            work = self.queue.get()
            work.execute()
            self.queue.task_done()


class Pool(object):

    def __init__(self, size):
        self.size = size
        self.queue = Queue.Queue()
        self.workers = []

        for i in xrange(self.size):
            t = Worker(self.queue)
            t.setDaemon(True)
            t.start()
            self.workers.append(t)

    def submit(self, work):
        self.queue.put(work)
