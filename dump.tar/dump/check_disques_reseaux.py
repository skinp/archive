#!/usr/bin/env python
#
#
#
#

import subprocess
import threading
import signal
import time
import sys
import os

class Ls(threading.Thread):
    ''' '''

    def __init__(self, folder):
        threading.Thread.__init__(self)
        self.folder = folder
        self.process = None
        self.rc = None

    def run(self):
        f = open('/dev/null', 'w')
        self.process = subprocess.Popen(['ls', self.folder], shell=False, stdout=f, stderr=subprocess.STDOUT)
        self.rc = self.process.wait()
        f.close()

    def kill(self):
        os.kill(self.process.pid, signal.SIGKILL)
        self.rc = -9


def get_mounted_net():
    '''Retourne les shares montes sur le system.'''

    mounts = set()
    f = open('/proc/mounts', 'r')
    for mount in f:
        disk, mp, type = mount.split()[:3]
        if not disk.startswith('#') and type in ['nfs', 'nfs4', 'cifs']:
            mounts.add(mp)

    return mounts


def get_expected_net():
    '''Retourne les shares qui devraient etre montes sur le system.'''

    mounts = set()
    f = open('/etc/fstab', 'r')
    for mount in f:
        disk, mp, type = mount.split()[0:3]
        if not disk.startswith('#') and type in ['nfs', 'nfs4', 'cifs']:
            mounts.add(mp)
    try:
        f = open('/opt/cifs/liste-shares', 'r')
        for mount in f:
            if not mount.startswith('#'):
                mounts.add(mount.split()[-1])
    except IOError:
        pass

    return mounts


def usage(programname):
    '''Affiche usage et quitte.'''

    print "usage: %s -s <seconds>" % sys.argv[0]
    sys.exit(3)


if __name__ == '__main__':

    # Valide la ligne de commande
    if len(sys.argv) != 3 or sys.argv[1] not in ['-s', '-S']:
        usage(sys.argv[0])
    try:
        waittime = float(sys.argv[2])
    except ValueError:
        usage(sys.argv[0])

    # Recupere l'etat des mounts
    mounted = get_mounted_net()
    expected = get_expected_net()

    # Regarde si on a des mounts qui devraient etre monte et qui le sont pas
    # on utilise feature des set python (set - set)
    errors = list()
    for diff in expected - mounted:
        errors.append("%s not mounted" % diff)

    # Lance les ls sur les mounts en parallele
    threads = []
    for mount in mounted:
        t = Ls(mount)
        t.setDaemon(True)
        t.start()
        threads.append(t)

    time.sleep(waittime)

    # On kill les threads apres le timeout et on set un message d'erreur si le RC != 0
    for t in threads:
        if t.isAlive():
            t.kill()
        if t.rc != 0:
            errors.append("%s bad return code %d" % (t.folder, t.rc))

    # Print et quitte avec bon RC
    if errors:
        rc = 2
        print '; '.join(errors)
    else:
        rc = 0
        print 'Mounts reseaux OK'
    sys.exit(rc)
