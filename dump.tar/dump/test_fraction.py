import unittest
from fraction import Fraction

class TestFraction(unittest.TestCase):

    def test_bad_types(self):
        self.assertRaises(TypeError, Fraction, 3, 0.1)
        self.assertRaises(TypeError, Fraction, "string", 1)

    def test_bad_bottom(self):
        self.assertRaises(ValueError, Fraction, 3, 0)

    def test_add(self):
        a = Fraction(1,2)
        b = Fraction(1,3)
        self.assertEqual(a+b, Fraction(5,6))

    def test_sub(self):
        a = Fraction(1,2)
        b = Fraction(1,3)
        self.assertEqual(a-b, Fraction(1,6))

    def test_mul(self):
        a = Fraction(1,2)
        b = Fraction(1,3)
        self.assertEqual(a*b, Fraction(1,6))

    def test_div(self):
        a = Fraction(1,2)
        b = Fraction(1,3)
        self.assertEqual(a/b, Fraction(3,2))

    def test_eq(self):
        a = Fraction(1,2)
        b = Fraction(1,2)
        self.assertTrue(a == b)

        b = Fraction(1,3)
        self.assertFalse(a == b)

    def test_gt(self):
        a = Fraction(1,2)
        b = Fraction(1,2)
        self.assertFalse(a > b)

        b = Fraction(1,3)
        self.assertTrue( a > b)

    def test_lt(self):
        a = Fraction(1,2)
        b = Fraction(1,2)
        self.assertFalse(a < b)

        a = Fraction(1,3)
        self.assertTrue(a < b)

if __name__ == '__main__':
    unittest.main()
