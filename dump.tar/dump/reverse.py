def reversed(l):
    original = list(l)
    new = []
    while original != []:
        new.append(original.pop())
    return new

if __name__ == '__main__':
    l = [5,4,3,2,1]
    print reversed(l)
