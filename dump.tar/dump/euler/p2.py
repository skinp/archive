def fibo(max):
    a = 0
    b = 1
    next = 0
    l = [a,b]
    while next <= max:
        next = a + b
        a, b = b, next
        if next < max:
            l.append(next)
    return l

print sum(i for i in fibo(4000000) if i % 2 == 0)
