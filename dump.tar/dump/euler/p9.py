import math
import sys

MAX = 1000

for a in xrange(1,MAX):
    for b in xrange(1,MAX):
        c_square = a**2 + b**2
        c = math.sqrt(c_square)
        if a + b + c == 1000:
            print int(a*b*c)
            sys.exit(0)

