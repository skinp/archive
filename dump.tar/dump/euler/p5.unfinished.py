MAX = 20
last = 1.0
end = False
while True:
    for i in range(1, MAX+1):
        if last % i != 0:
            end = False
            break
        else:
            end = True

    if end:
        break
    last += 1

print last
