import string

def get_names(file):
    with open(file, "r") as f:
        names = f.read().split(",")

    names = [ string.replace(i, '"', '') for i in names ]
    names = sorted(names)
    return names

ALPHABET = "abcdefghijklmnopqrstuvwxyz"
def get_name_score(name):
    sum = 0
    for letter in name:
        sum += ALPHABET.index(letter.lower()) + 1
    return sum

def main():
    sum = 0
    counter = 1

    names = get_names("p22.txt")
    for name in names:
        sum += get_name_score(name) * counter
        counter += 1

    print sum

if __name__ == '__main__':
    main()
