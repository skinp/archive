def next_fibo(a,b):
    return a + b

a,b = 1,1
number = next_fibo(a,b)

# On doit compter 1,1,2
term = 3

while number < 10**999:
    a,b = b, number
    number = next_fibo(a,b)
    term += 1

print term
