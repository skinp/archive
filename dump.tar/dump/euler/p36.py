MAX = 1000000

def is_palindrome(s):
    if str(s) == str(s)[::-1]:
        return True
    return False

def binary_str(number):
    return '{0:b}'.format(number)

sum = 0
for i in range(MAX):
    if is_palindrome(i) and is_palindrome(binary_str(i)):
        print i, binary_str(i)
        sum += i

print sum
