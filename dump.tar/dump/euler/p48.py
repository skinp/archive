NUMBER = 1000
sum = 0
for i in range(1,NUMBER+1):
    sum += i ** i

print str(sum)[-10:]
