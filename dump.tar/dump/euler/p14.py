MAX = 1000000

def rules(n):
    if n % 2 == 0:
        return n/2
    else:
        return 3*n + 1

def func(n):
    chain = [n]
    while n != 1:
        n = rules(n)
        chain.append(n)
    return chain

longuest = []
longuest_len = 0

for i in range(1,MAX):
    chain = func(i)

    if len(chain) > longuest_len:
        longuest = chain
        longuest_len = len(longuest)

print(longuest[0])
