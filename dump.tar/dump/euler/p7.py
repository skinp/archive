list_primes = [2,3,5,7,11,13]
num = 15
while len(list_primes) != 10001:
    if all(num % i != 0 for i in list_primes):
        list_primes.append(num)
    num += 2

print list_primes[len(list_primes)-1]
