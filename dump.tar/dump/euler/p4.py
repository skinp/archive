MIN = 100
MAX = 1000
last_palindrome = None
for i in range(MIN, MAX):
    for j in range(MIN, MAX):
        product = i*j
        if str(product) == str(product)[::-1]:
            print "%s x %s = %s" % (i, j, product)
            if product > last_palindrome:
                last_palindrome = product

print last_palindrome

