MIN = 2
MAX = 100

terms = set()
for i in range(MIN, MAX+1):
    for j in range(MIN, MAX+1):
        terms.add(i**j)

print len(terms)
