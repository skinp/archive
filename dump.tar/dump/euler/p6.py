MAX = 100
sum_of_square = 0
sum = 0
for i in xrange(1, MAX+1):
    sum += i
    sum_of_square += i ** 2

square_of_sum = sum ** 2

print square_of_sum - sum_of_square
