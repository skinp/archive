MAX = 2000000
primes = []

last = 3

num = 5
while last < MAX:
    if num % 3 != 0:
        if all(num % i != 0 for i in primes):
            primes.append(num)
            last = num
    num += 2

print "done"
