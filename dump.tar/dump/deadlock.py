import threading
import time


class Worker(threading.Thread):
    def __init__(self, name, l1, l2):
        threading.Thread.__init__(self)
        self.name = name
        self.l1 = l1
        self.l2 = l2

    def run(self):

        self.l1.acquire()
        print "%s acquired l1" % self.name
        time.sleep(1)

        self.l2.acquire()
        print "%s acquired l2" % self.name
        time.sleep(1)

        print "%s releasing..." % self.name
        self.l1.release()
        self.l2.release()


if __name__ == "__main__":
    lock1 = threading.Lock()
    lock2 = threading.Lock()

    worker1 = Worker("w1", lock1, lock2)
    worker2 = Worker("w2", lock2, lock1)

    worker1.start()
    worker2.start()
