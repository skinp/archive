import random

SENTENCE = "methinks it is like a weasel"
SIZE = len(SENTENCE)

def percentage(part, whole):
    return int(100 * float(part)/float(whole))

def gen_random_sentence():
    alphabet = list('abcdefghijklmnopqrstuvwxyz ')
    return ''.join([random.choice(alphabet) for x in xrange(SIZE)])

def compare_and_score(s):
    score = 0
    for char in xrange(SIZE):
        if s[char] == SENTENCE[char]:
            score +=1
    return percentage(score,SIZE)

if __name__ == '__main__':
    found = False
    counter = 0
    best_score = 0
    best_sentence = ""

    while not found:
        random_sentence = gen_random_sentence()
        score = compare_and_score(random_sentence)

        if score == 100:
            found = True
            print "Found it!"
        elif score > best_score:
            best_score = score
            best_sentence = random_sentence

        counter += 1

        if counter == 1000 and not found:
            print best_score, best_sentence
            counter = 0
