import random

names = ['patrick', 'marie', 'eddy', 'valerie', 'vincent', 'guylaine']

NUM_ENTRIES = 10000
MAX_RAND_NUM = 100
for i in range(NUM_ENTRIES):
    print random.choice(names), random.randrange(MAX_RAND_NUM)
