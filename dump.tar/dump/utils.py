import subprocess
import sys

def run_command(cmd, data=None):
    ''' runs a command and return results. supports sending stdin data'''

    if isinstance(cmd, list):
        shell = False
    elif isinstance(cmd, basestring):
        shell = True
    else:
        raise TypeError("command must be a string or a list")

    std_in = None
    if data:
        std_in = subprocess.PIPE

    try:
        process = subprocess.Popen(cmd, shell=shell, stdin=std_in, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if data:
            process.stdin.write(data)
            process.stdin.write('\\n')
        out, err = process.communicate()
        rc = process.returncode
    except (OSError, IOError), e:
        sys.stderr.write("ERROR: run_command(%s): %s\n" % (cmd, e))
        sys.exit(1)

    return (out, err, rc)


class Counter(dict):

    def __init__(self):
        dict.__init__(self)

    def insert(self, data):
        if dict.__contains__(self, data):
            dict.__setitem__(self, data, dict.__getitem__(self, data) + 1)
        else:
            dict.__setitem__(self, data, 1)

    def most_common(self, n):
        return sorted(dict.items(self), key=lambda x: x[1])[-n:][::-1]
