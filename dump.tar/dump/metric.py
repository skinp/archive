class Metric:

    def __init__(self, name, threshold):
        self.name = name
        self.threshold = threshold
        self.value = None

    def refreshValue():
        pass

    def is_ok(self):
        if self.value > self.threshold or self.value is None:
            return False
        return True

class Load5m(Metric):

    def refreshValue(self):
        with open("/proc/loadavg", "r") as f:
            data = f.read()
        self.value = float(data.split()[0])

if __name__ == '__main__':
    load5m = Load5m("load5m", 1.0)
    load5m.refreshValue()
    print load5m.value
    print load5m.is_ok()
