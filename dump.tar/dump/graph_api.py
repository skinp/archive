import urllib2
import json

BASE_URL = "http://lmon531a.le500.loto-quebec.com/"

class APIError(Exception):
    pass

def get_servers():
    SERVERS_URL = "metrics/find/?query=servers.*"
    try:
        data = urllib2.urlopen(BASE_URL + SERVERS_URL).read()
    except:
        raise APIError("error getting server list")

    return [ i.get('text', None) for i in json.loads(data) ]

if __name__ == '__main__':
    print get_servers()
