class BinaryTree:

    def __init__(self, name, value):
        self.name = name
        self.value = value
        self.left = None
        self.right = None

    def insert(self, name, value):
        if value < self.value:
            if self.left:
                self.left.insert(name, value)
            else:
                self.left = BinaryTree(name, value)
        else:
            if self.right:
                self.right.insert(name, value)
            else:
                self.right = BinaryTree(name, value)

    def search(self, value):
        if self.value == value:
            return self
        elif value < self.value and self.left:
            return self.left.search(value)
        elif self.right:
            return self.right.search(value)
        else:
            return None

    def leafs(self):
        l = list()
        if not self.left and not self.right:
            return [self]
        else:
            if self.left:
                l += self.left.leafs()
            if self.right:
                l += self.right.leafs()
            return l

    def depth(self):
        left_depth = self.left.depth() if self.left else 0
        right_depth = self.right.depth() if self.right else 0
        return max(left_depth, right_depth) + 1

    def traverse(self):
        l = list()
        if self.left:
            l += self.left.traverse()
        l += [self]
        if self.right:
            l += self.right.traverse()
        return l


    def __str__(self):
        return "%s %s" %(self.name, str(self.value))

    def __repr__(self):
        return self.__str__()


if __name__ == '__main__':
    tree = BinaryTree("root", 2)
    tree.insert("n1", 7)
    tree.insert("n2", 3)
    tree.insert("n3", 5)
    tree.insert("n4", 9)
    tree.insert("n5", 1)

    print tree.depth()
    print tree.traverse()
    print tree.leafs()
