import sqlite3
import memcache
import random
import sys

DB_FILE = '/tmp/persons.db'

class Person:

    def __init__(self, name, age, id=None):
        if id:
            self.id = id
        else:
            self.id = generate_id()
        self.name = name
        self.age = age

    def __str__(self):
        return "%d: %s is %d yo" % (self.id, self.name, self.age)


class PersonDAO:

    def __init__(self):
        self.conn = sqlite3.connect(DB_FILE)
        self.mc = memcache.Client(['127.0.0.1:11211'])

    def get_all(self):
        c = self.conn.cursor()
        persons = list()
        for row in c.execute("SELECT name, age, id FROM person"):
            persons.append(Person(*row))
        return persons

    def get_person(self, id):
        person = self.mc.get('person:%s' % str(id))
        if not person:
            c = self.conn.cursor()
            c.execute("SELECT name, age FROM person WHERE id = %d" % id)
            person = c.fetchone()

            if not person:
                return None

            person = Person(person[0], int(person[1]), int(id))
            self.mc.set('person:%s' % str(id), person)
        return person

    def add_person(self, person):
        c = self.conn.cursor()
        c.execute("INSERT INTO person VALUES (%d, '%s', %d)" % (person.id, person.name, person.age))
        self.conn.commit()

    def update_person(self, person):
        c = self.conn.cursor()
        c.execute("UPDATE person SET name = '%s', age = %d WHERE id = %d" % (person.name, person.age, person.id))
        self.conn.commit()
        if c.rowcount == 1:
            c = self.conn.cursor()
            c.execute("SELECT name, age FROM person WHERE id = %d" % id)
            data = c.fetchone()
            new_person = Person(data[0], data[1], id)
            self.mc.set('person:%s' % id, new_person)
            self.conn.commit()
            return True
        else:
            return False

    def delete_person(self, id):
        c = self.conn.cursor()
        c.execute("DELETE FROM person WHERE id = %d" % id)
        self.conn.commit()
        self.mc.delete('person:%s' %id)
        if c.rowcount == 1:
            return True
        else:
            return False


def generate_id():
    existing = [ x.id for x in PersonDAO().get_all() ]
    while True:
        new_id = hash(random.random())
        if new_id not in existing:
            return new_id


def init_db():
    conn = sqlite3.connect(DB_FILE)
    c = conn.cursor()
    c.execute("CREATE TABLE IF NOT EXISTS person (id INTEGER PRIMARY KEY, name TEXT, age INTERGER)")
    conn.commit()
    conn.close()


if __name__ == '__main__':
    init_db()

    def usage(programname):
        print "usage: %s [list|print|add|update|delete]' % programname"
        sys.exit(1)

    dao = PersonDAO()

    if len(sys.argv) != 2:
        usage(sys.argv[0])

    elif sys.argv[1] == 'list':
        for person in dao.get_all():
            print person

    elif sys.argv[1] == 'print':
        id = int(raw_input("id: "))
        person = dao.get_person(id)
        if person:
            print person
        else:
            print "No record for id %d" % id

    elif sys.argv[1] == 'add':
        name = raw_input("name: ")
        age = int(raw_input("age: "))
        new_person = Person(name, age)
        dao.add_person(new_person)

    elif sys.argv[1] == 'update':
        id = int(raw_input("id: "))
        name = raw_input("name: ")
        age = int(raw_input("age: "))
        updated_person = Person(name, age, id)
        if not dao.update_person(updated_person):
            print "No record for id %d" % id

    elif sys.argv[1] == 'delete':
        id = int(raw_input("id: "))
        if not dao.delete_person(id):
            print "No record for id %d" % id

    else:
        usage(sys.argv[0])
