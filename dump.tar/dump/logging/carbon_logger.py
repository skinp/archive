import logging
import random
from carbon_handler import CarbonHandler

if __name__ == '__main__':

    logger = logging.getLogger("toto.titi.tata")
    logger.setLevel(logging.DEBUG)

    handler = CarbonHandler('lmon531a.le500.loto-quebec.com', 2003)
    #handler = CarbonHandler('127.0.0.1', 2003)
    #handler = logging.StreamHandler()
    handler.setLevel(logging.DEBUG)

    logger.addHandler(handler)

    logger.debug(random.randrange(0, 100))

