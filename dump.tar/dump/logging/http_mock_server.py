from bottle import route, run, request

@route('/', method='GET')
def index():
    print request.query.msg
    return 'OK'

if __name__ == '__main__':
    run(host='0.0.0.0', port=8080)
