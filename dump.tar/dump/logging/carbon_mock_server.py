import socket
import thread
import sys

HOST = '127.0.0.1'
PORT = 2003

ADDR = (HOST, PORT)

def connection_handler(clientsocket):
    message = ""
    while True:
        data = clientsocket.recv(1024)
        message += data
        if not data:
            break

    print message
    clientsocket.close()

if __name__ == '__main__':
    ssock = socket.socket()
    ssock.bind(ADDR)
    ssock.listen(2)

    while True:
        csock, addr = ssock.accept()
        thread.start_new_thread(connection_handler, (csock,))
