import logging
from logging.handlers import HTTPHandler
import random

if __name__ == '__main__':

    logger = logging.getLogger("toto.titi.tata")
    logger.setLevel(logging.DEBUG)

    handler = HTTPHandler('localhost:8080', '/')
    handler.setLevel(logging.DEBUG)
    logger.addHandler(handler)

    logger.debug(random.randrange(0, 100))

