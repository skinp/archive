import socket
import time
import random


s = socket.socket()
s.connect(('127.0.0.1', 2003))
while True:
    metric = "metric.value"
    value = random.randrange(20, 40)
    date = int(time.time())

    msg = "%s %d %d\n" % (metric, value, date)

    print msg,
    s.sendall(msg)

    time.sleep(1)

s.close()
