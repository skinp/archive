def sorting(l):
    original = list(l)
    result = []
    for i in range(len(original)):
        small = None
        for j in original:
            if small == None:
                small = j
            elif small > j:
                small = j
        result.append(small)
        original.remove(small)
    return result

if __name__ == '__main__':
    l = [2,4,6,1,10,0,-1,30]
    print sorting(l)
