import sys

if __name__ == '__main__':
    if len(sys.argv) > 1:
        f = open(sys.argv[1])
        input = f.readlines
    else:
        input = sys.stdin.readlines

    d = dict()
    for line in input():
        name, score = line.split()
        if name in d:
            d[name] += int(score)
        else:
            d[name] = int(score)

    for name, score in sorted(d.items(), key=lambda x: x[1])[::-1]:
        print name, score
