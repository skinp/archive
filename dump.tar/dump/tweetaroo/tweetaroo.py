#!/usr/bin/env python
# tweetaroo.py
import sys
import urllib
import json

class Timeline(object):

    url = "http://api.twitter.com/1/statuses/user_timeline.json?count=%(count)d&screen_name=%(username)s"

    def __init__(self, username):
        self.username = username
        self.tweets = []

    def load(self):
        try:
            request = urllib.urlopen(Timeline.url % {'count': 100, 'username': self.username})
        except IOError, e:
            print "Error connecting to url"
            sys.exit(1)

        if request.getcode() == 400:
            print "Allowed request exceeded"
            sys.exit(1)

        content = request.read()
        try:
            json_tweets = json.loads(content)
        except ValueError, e:
            print "Bad json..."
            sys.exit(1)
        self.tweets = [Tweet(tweet) for tweet in json_tweets]

    def calc_obsession(self):
        word_count = {}
        for tweet in self.tweets:
            for word in tweet.get_words():
                if len(word) > 1:
                    word_count[word] = word_count.get(word, 0) + 1
        return sorted(word_count.iteritems(), key=lambda x: x[1])

stopwords = set([line.strip() for line in open('stopwords.txt')])

class Tweet(object):
    def __init__(self, item):
        self.item = item
        self.text = item['text']

    def get_words(self):
        words = self.text.lower().split()
        return [word for word in words if word not in stopwords]

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Usage: %s <twitter_user>" % sys.argv[0]
        print "\tprints the 10 words <twitter_user> is most obsessed with"
        sys.exit(1)
    t = Timeline(sys.argv[1])
    t.load()
    for word in t.calc_obsession()[:-10:-1]:
        print word[0], word[1]
