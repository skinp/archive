def bfs(root, value):
    q = list()
    visited = []
    q.insert(0, root)
    visited.append(root)

    while q:
        node = q.pop()
        print node.data
        if node.data == value:
            return node

        if node.left not in visited:
            visited.append(node.left)
            q.insert(0, node.left)

        if node.right not in visited:
            visited.append(node.right)
            q.insert(0, node.right)

    return None


