from node import Node
from bfs import bfs

root = Node(3)
n1 = Node(4)
n2 = Node(6)
n3 = Node(10)
n4 = Node(31)
n5 = Node(-1)
n6 = Node(1)

root.left = n1
root.right = n2

n1.left = n3
n1.right = n4

n2.left = n5
n2.right = n6

print bfs(root, 1).data
