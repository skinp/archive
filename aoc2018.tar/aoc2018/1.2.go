package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

func main() {
	sum := 0
	seen := make([]int, 0)
	for {
		f, _ := os.Open("input/1.txt")
		scanner := bufio.NewScanner(f)
		for scanner.Scan() {
			freq, _ := strconv.Atoi(scanner.Text())
			sum += freq
			for _, i := range seen {
				if sum == i {
					fmt.Println(sum)
					os.Exit(0)
				}
			}
			seen = append(seen, sum)
		}
	}

}
