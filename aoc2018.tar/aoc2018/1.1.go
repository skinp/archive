package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

func main() {
	sum := 0
	f, _ := os.Open("input/1.txt")
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		freq, _ := strconv.Atoi(scanner.Text())
		sum += freq
	}
	fmt.Println(sum)
}
